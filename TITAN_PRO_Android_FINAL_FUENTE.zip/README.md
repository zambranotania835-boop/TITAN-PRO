# TITAN PRO Android — beta 0.4

Este es el **proyecto fuente Android**, no un APK ya compilado. La app abre la versión web publicada de TITAN PRO dentro de una ventana Android (WebView):

https://stupendous-youtiao-cfa223.netlify.app/

## Qué hace
- Nombre de app: TITAN PRO.
- Abre la versión publicada para que los cambios web sigan apareciendo sin recompilar la interfaz cada vez.
- Requiere conexión a internet.
- Este envoltorio no implementa por sí solo Firebase nativo. La autenticación y el chat dependen de los servicios que tenga configurados la web publicada.

## Compilar APK automáticamente con GitHub Actions
1. Sube el contenido de esta carpeta `TITAN_PRO_Android` a un repositorio nuevo de GitHub.
2. En GitHub abre **Actions** y permite ejecutar workflows si te lo solicita.
3. Abre el workflow **Build TITAN PRO APK**, pulsa **Run workflow** (o espera a que termine el primer push).
4. Cuando termine correctamente, abre esa ejecución y descarga el artefacto `TITAN-PRO-debug-apk`.
5. Descomprime el artefacto y abre el APK en tu teléfono Android para instalarlo. Android puede pedir que permitas instalar desde ese origen.

## Compilación local
Requiere Android Studio, JDK 17 y Android SDK 35. Abre esta carpeta (donde está `settings.gradle`) y ejecuta la tarea `assembleDebug`. El APK resultante estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Importante
- No se ha generado ni probado un APK en este entorno; el archivo que se entrega es el código fuente preparado para compilar.
- El archivo `google-services.json` no se usa en esta versión WebView porque no integra Firebase nativo. No lo pongas en el proyecto esperando que conecte automáticamente la web.
- Antes de compartir con otras personas, verifica que el inicio de sesión y el chat de la web estén conectados al backend correcto. No compartas claves privadas ni `service_role`.
